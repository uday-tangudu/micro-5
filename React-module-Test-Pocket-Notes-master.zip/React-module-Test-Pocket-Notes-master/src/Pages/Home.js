import React from 'react';
import HomePage from '../components/SideBarAndMessageArea';

const Home = () => {
  return (
    <div style={{ display: 'flex' }}>
      <HomePage />
    </div>
  );
};

export default Home;
